//
//  SuryaNamskarVC.swift
//  MyHHS_iOS
//
//  Created by Patel on 07/01/2022.
//

import UIKit
import Foundation
import Charts
import TinyConstraints

struct surynamaskarModel {
    var date: Date
    var value: Double
    var memberId: String
}

class SuryaNamskarVC: UIViewController {
    
    @IBOutlet weak var chartView: BarChartView!
        
    var dicMember = [[String:Any]]()
    
    var memberIds: String = ""
    
    var suryaNamskarResponseDM : SuryaNamskarResponseDM?
    
    var suryaNamskarData : [SuryaNamskarData] {
        return suryaNamskarResponseDM?.suryaNamskarData ?? []
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view
        self.getMemberAPI()
    }

    override func viewWillAppear(_ animated: Bool) {
//        navigationBarDesign(txt_title: "Suryanamskar", showbtn: "back")
        navigationBarWithRightButtonDesign(txt_title: "Suryanamskar", showbtn: "back", rightImg: "plus_white", bagdeVal: "", isBadgeHidden: true)
        self.getSuryaNamskarDataAPI()
    }

    override func rightBarItemClicked(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddSuryaNamskarCountVC") as! AddSuryaNamskarCountVC
        vc.dicMember = self.dicMember
        vc.modalPresentationStyle = UIModalPresentationStyle.fullScreen
//        vc.modalTransitionStyle = UIModalTransitionStyle.crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    // MARK: - Chart
    func setData() {

        var objects: [surynamaskarModel] = []
        for suryaNamskar in suryaNamskarData {

            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "en_US_POSIX") // set locale to reliable US_POSIX
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date = dateFormatter.date(from:suryaNamskar.count_date ?? "2022-01-01")!

            objects.append(surynamaskarModel(date: date, value: (suryaNamskar.count! as NSString).doubleValue, memberId: suryaNamskar.member_id ?? "0"))
            print(objects)
        }
        
        let grouped = objects.categorise { $0.memberId
        }
        
        print(grouped)


//        for x in 1..<4 {
//            var dayComponent    = DateComponents()
//            dayComponent.day    = x // For removing one day (yesterday): -1
//            let theCalendar     = Calendar.current
//            let nextDate        = theCalendar.date(byAdding: dayComponent, to: Date())
//
//            objects = [
//                surynamaskarModel(date: nextDate!, value: 6.0, memberId: ""),surynamaskarModel(date: nextDate!, value: 10.0, memberId: ""), surynamaskarModel(date: nextDate!, value: 5.0, memberId: ""), surynamaskarModel(date: nextDate!, value: 3.0, memberId: "")
//            ]
//        }

        // (objects is defined as an array of struct with date and value)
        // Define the reference time interval
        var referenceTimeInterval: TimeInterval = 0
        if let minTimeInterval = (objects.map { $0.date.timeIntervalSince1970 }).min() {
                referenceTimeInterval = minTimeInterval
            }

            // Define chart xValues formatter
            let formatter = DateFormatter()
            formatter.dateStyle = .short
            formatter.timeStyle = .none
            formatter.locale = Locale.current

            let xValuesNumberFormatter = ChartXAxisFormatter(referenceTimeInterval: referenceTimeInterval, dateFormatter: formatter)

            // Define chart entries
            var entries = [ChartDataEntry]()
            for object in objects {
                let timeInterval = object.date.timeIntervalSince1970
                let xValue = (timeInterval - referenceTimeInterval) / (3600 * 24)

                let yValue = object.value
                let entry = BarChartDataEntry(x: xValue,
                                              y: yValue,
                                              data: xValuesNumberFormatter.stringForValue(xValue, axis: nil))
                entries.append(entry)
            }

        let set1 = BarChartDataSet(entries: entries, label: "Suryanamskar")
        let set2 = BarChartDataSet(entries: entries, label: "Suryanamskar2")
        let data = BarChartData(dataSet: set1)
//        let data = BarChartData(dataSets: [set1,set2])
        let chartData = BarChartData(dataSet: set1)
        let xAxis = self.chartView.xAxis
        xAxis.labelPosition = .bottom
//        xAxis.labelCount = entries.count

        self.chartView.xAxis.valueFormatter = xValuesNumberFormatter
        self.chartView.data = chartData
//        self.chartView.setVisibleXRangeMaximum(7)

    }

    func getSuryaNamskarDataAPI() {

        var parameters: [String: Any] = [:]
        parameters["is_api"] = "true"
        parameters["member_id"] = "749,986,547" //"547" //  self.memberIds

        print(parameters)
        //APIUrl.get_suryanamaskar
        APIManager.sharedInstance.callPostApi(url: "https://stg.myhss.org.uk/api/v1/suryanamaskar/get_suryanamaskar_count", parameters: parameters) { (jsonData, error) in
            if error == nil
            {
                do {
                    self.suryaNamskarResponseDM = try JSONDecoder().decode(SuryaNamskarResponseDM.self, from: (jsonData?.rawData())!)
                    print(self.suryaNamskarResponseDM?.suryaNamskarData?.count as Any)
                    self.setData()
                } catch {
                    print("Error : \(error)")
                    if let strError = jsonData!["message"].string {
                        showAlert(title: APP.title, message: strError)
                    }
                }
            }
        }
    }

    func getMemberAPI() {

        var parameters: [String: Any] = [:]
        parameters["user_id"] = _appDelegator.dicMemberProfile![0]["user_id"] as? String //    dicUserDetails["user_id"]
        parameters["member_id"] = _appDelegator.dicDataProfile![0]["member_id"] as? String //  dicUserDetails["member_id"]
        parameters["tab"] = "family"   //  family or kendra or shakha
        parameters["status"] = "all"  //  status = all, 0 pending, 1 active, 3 rejected, 4 inactive
        parameters["start"] = "0"
        parameters["length"] = "20"
        parameters["search"] = ""

        print(parameters)

        APIManager.sharedInstance.callPostApi(url: APIUrl.get_listing, parameters: parameters) { (jsonData, error) in
            if error == nil
            {
                if let status = jsonData!["status"].int
                {
                    if status == 1
                    {
                        self.dicMember.removeAll()
                        let arr = jsonData!["data"]

                        var dictStatic = [String : Any]()
                        dictStatic["id"] = _appDelegator.dicDataProfile![0]["member_id"] as? String
                        dictStatic["name"] = "\(_appDelegator.dicMemberProfile![0]["first_name"] as? String ?? "") \(_appDelegator.dicMemberProfile![0]["last_name"] as? String ?? "")"
                        self.memberIds = _appDelegator.dicDataProfile![0]["member_id"] as? String ?? ""
                        
                        for index in 0..<arr.count {
                            var dict = [String : Any]()
                            dict["id"] = "\(arr[index]["member_id"])"
                            dict["name"] = "\(arr[index]["first_name"]) \(arr[index]["last_name"])"
                            self.dicMember.append(dict)
                            self.memberIds += ",\(arr[index]["member_id"])"
                        }
                    }else {
                            self.dicMember.removeAll()
                            //  Add Static Recoard
                            var dictStatic = [String : Any]()
                            dictStatic["id"] = _appDelegator.dicDataProfile![0]["member_id"] as? String
                            dictStatic["name"] = "\(_appDelegator.dicMemberProfile![0]["first_name"] as? String ?? "") \(_appDelegator.dicMemberProfile![0]["last_name"] as? String ?? "")"
                            self.dicMember.append(dictStatic)
                        self.memberIds = _appDelegator.dicDataProfile![0]["member_id"] as? String ?? ""
                    }
                }
                else {
                    if let strError = jsonData!["message"].string {
                        showAlert(title: APP.title, message: strError)
                    }
                }
            }
        }
    }
}

extension SuryaNamskarVC : ChartViewDelegate {
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        print(entry)
    }
}

class ChartXAxisFormatter: NSObject {
    fileprivate var dateFormatter: DateFormatter?
    fileprivate var referenceTimeInterval: TimeInterval?

    convenience init(referenceTimeInterval: TimeInterval, dateFormatter: DateFormatter) {
        self.init()
        self.referenceTimeInterval = referenceTimeInterval
        self.dateFormatter = dateFormatter
    }
}

extension ChartXAxisFormatter: IAxisValueFormatter {
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        guard let dateFormatter = dateFormatter,
        let referenceTimeInterval = referenceTimeInterval
        else {
            return ""
        }

        let date = Date(timeIntervalSince1970: value * 3600 * 24 + referenceTimeInterval)
        return dateFormatter.string(from: date)
    }
}

public extension Sequence {
    func categorise<U : Hashable>(_ key: (Iterator.Element) -> U) -> [U:[Iterator.Element]] {
        var dict: [U:[Iterator.Element]] = [:]
        for el in self {
            let key = key(el)
            if case nil = dict[key]?.append(el) { dict[key] = [el] }
        }
        return dict
    }
}
